package dev.zeya.fabricmoon.mixin;

import net.minecraft.world.entity.projectile.FishingHook;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(FishingHook.class)
public interface FishingHookAccessor {
   @Accessor("biting")
   boolean zeyafabricmoon$isBiting();
}
